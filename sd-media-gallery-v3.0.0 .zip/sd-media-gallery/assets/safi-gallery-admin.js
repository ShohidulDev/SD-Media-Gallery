/* Safi Gallery – Admin JS v2.0 | ShohidulDev */
(function($){
    'use strict';
    // Custom CSS page clear button
    var clearBtn = document.getElementById('safi-clear-css');
    if(clearBtn){
        clearBtn.addEventListener('click', function(){
            if(confirm('Clear all custom CSS?')){
                document.getElementById('safi_custom_css').value = '';
            }
        });
    }
    // Preset buttons
    document.querySelectorAll('.safi-preset-btn').forEach(function(btn){
        btn.addEventListener('click', function(){
            var ta = document.getElementById('safi_custom_css');
            if(ta) ta.value = this.dataset.css || '';
            document.querySelectorAll('.safi-preset-btn').forEach(function(b){ b.classList.remove('active'); });
            this.classList.add('active');
        });
    });
})(jQuery);
