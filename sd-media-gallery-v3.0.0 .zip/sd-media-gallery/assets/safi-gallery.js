/* ============================================================
   Safi Gallery – lightbox & keyboard navigation
   ============================================================ */
(function ($) {
    'use strict';

    var lb       = document.getElementById('safi-lightbox');
    var backdrop = document.getElementById('safi-lb-backdrop');

    if (!lb || !backdrop) return;   // shortcode not on page

    var lbImg     = lb.querySelector('.safi-lb-img');
    var lbTitle   = lb.querySelector('.safi-lb-title');
    var lbCounter = lb.querySelector('.safi-lb-counter');
    var lbThumbs  = lb.querySelector('.safi-lb-thumbs');
    var btnClose  = lb.querySelector('.safi-lb-close');
    var btnPrev   = lb.querySelector('.safi-lb-prev');
    var btnNext   = lb.querySelector('.safi-lb-next');

    var state = {
        images : [],
        index  : 0,
        title  : ''
    };

    /* ---- Open ---- */
    function open(images, index, title) {
        state.images = images;
        state.index  = index;
        state.title  = title;

        buildThumbs();
        show(index);

        lb.hidden       = false;
        backdrop.hidden = false;
        document.body.style.overflow = 'hidden';
        btnClose.focus();
    }

    /* ---- Show image at index ---- */
    function show(i) {
        i = Math.max(0, Math.min(i, state.images.length - 1));
        state.index = i;

        var img = state.images[i];
        lbImg.src     = img.full;
        lbImg.alt     = state.title + ' ' + (i + 1);
        lbTitle.textContent   = state.title;
        lbCounter.textContent = (i + 1) + ' / ' + state.images.length;

        // Update thumb active state
        lbThumbs.querySelectorAll('.safi-lb-thumb').forEach(function (t, idx) {
            t.classList.toggle('safi-active', idx === i);
        });

        // Show/hide arrows
        btnPrev.classList.toggle('safi-hidden', i === 0);
        btnNext.classList.toggle('safi-hidden', i === state.images.length - 1);
    }

    /* ---- Build thumbnails ---- */
    function buildThumbs() {
        lbThumbs.innerHTML = '';
        state.images.forEach(function (img, idx) {
            var t = document.createElement('img');
            t.src       = img.thumb;
            t.className = 'safi-lb-thumb';
            t.alt       = state.title + ' thumbnail ' + (idx + 1);
            t.addEventListener('click', function () { show(idx); });
            lbThumbs.appendChild(t);
        });
    }

    /* ---- Close ---- */
    function close() {
        lb.hidden       = true;
        backdrop.hidden = true;
        document.body.style.overflow = '';
        lbImg.src = '';
    }

    /* ---- Card click ---- */
    document.querySelectorAll('.safi-gallery-card').forEach(function (card) {
        card.setAttribute('tabindex', '0');
        card.setAttribute('role', 'button');

        function handleOpen() {
            var images = JSON.parse(card.dataset.images || '[]');
            if (!images.length) return;
            open(images, 0, card.dataset.title || '');
        }

        card.addEventListener('click', handleOpen);
        card.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                handleOpen();
            }
        });
    });

    /* ---- Controls ---- */
    btnClose.addEventListener('click', close);
    backdrop.addEventListener('click', close);
    btnPrev.addEventListener('click', function () { show(state.index - 1); });
    btnNext.addEventListener('click', function () { show(state.index + 1); });

    /* ---- Keyboard ---- */
    document.addEventListener('keydown', function (e) {
        if (lb.hidden) return;
        if (e.key === 'Escape')      close();
        if (e.key === 'ArrowLeft')   show(state.index - 1);
        if (e.key === 'ArrowRight')  show(state.index + 1);
    });

    /* ---- Touch swipe ---- */
    var touchStart = null;
    lb.addEventListener('touchstart', function (e) {
        touchStart = e.changedTouches[0].clientX;
    }, { passive: true });
    lb.addEventListener('touchend', function (e) {
        if (touchStart === null) return;
        var delta = e.changedTouches[0].clientX - touchStart;
        if (Math.abs(delta) > 50) {
            delta < 0 ? show(state.index + 1) : show(state.index - 1);
        }
        touchStart = null;
    }, { passive: true });

})(jQuery);
