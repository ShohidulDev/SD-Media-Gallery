<?php
/**
 * Plugin Name: SD Media Gallery
 * Plugin URI:  https://github.com/ShohidulDev/sd-media-gallery
 * Description: Professional project image gallery with lightbox, thumbnails, Custom CSS editor, and category filtering. Shortcode: [sd_gallery]
 * Version:     3.0.0
 * Author:      Shohidul Dev
 * Author URI:  https://github.com/ShohidulDev
 * License:     GPL-2.0+
 * Text Domain: sd-media-gallery
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SD_GALLERY_VERSION', '3.0.0' );
define( 'SD_GALLERY_URL',     plugin_dir_url( __FILE__ ) );
define( 'SD_GALLERY_PATH',    plugin_dir_path( __FILE__ ) );

/* ─────────────────────────────────────────
   1. CPT + TAXONOMY
───────────────────────────────────────── */
add_action( 'init', 'sd_gallery_register_cpt' );
function sd_gallery_register_cpt() {
    register_taxonomy( 'sd_gallery_cat', 'sd_project', [
        'label'        => 'Gallery Categories',
        'hierarchical' => true,
        'show_in_rest' => true,
        'rewrite'      => [ 'slug' => 'sd-gallery-category' ],
    ] );
    register_post_type( 'sd_project', [
        'label'         => 'Projects',
        'public'        => false,
        'show_ui'       => true,
        'show_in_menu'  => false,
        'show_in_rest'  => true,
        'menu_icon'     => 'dashicons-format-gallery',
        'supports'      => [ 'title', 'thumbnail' ],
        'taxonomies'    => [ 'sd_gallery_cat' ],
        'menu_position' => 25,
        'labels'        => [
            'name'          => 'Projects',
            'singular_name' => 'Project',
            'add_new_item'  => 'Add New Project',
            'edit_item'     => 'Edit Project',
        ],
    ] );
}

/* ─────────────────────────────────────────
   2. ADMIN MENU
───────────────────────────────────────── */
add_action( 'admin_menu', 'sd_gallery_admin_menu' );
function sd_gallery_admin_menu() {
    add_menu_page( 'SD Media Gallery', 'SD Gallery', 'manage_options', 'sd-gallery-dashboard', 'sd_gallery_dashboard_page', 'dashicons-format-gallery', 25 );
    add_submenu_page( 'sd-gallery-dashboard', 'Dashboard',       'Dashboard',     'manage_options', 'sd-gallery-dashboard',  'sd_gallery_dashboard_page' );
    add_submenu_page( 'sd-gallery-dashboard', 'All Projects',    'All Projects',  'manage_options', 'edit.php?post_type=sd_project' );
    add_submenu_page( 'sd-gallery-dashboard', 'Add New Project', 'Add New',       'manage_options', 'post-new.php?post_type=sd_project' );
    add_submenu_page( 'sd-gallery-dashboard', 'Custom CSS',      'Custom CSS',    'manage_options', 'sd-gallery-css',        'sd_gallery_css_page' );
    add_submenu_page( 'sd-gallery-dashboard', 'Settings',        'Settings',      'manage_options', 'sd-gallery-settings',   'sd_gallery_settings_page' );
}

/* ─────────────────────────────────────────
   3. ADMIN ENQUEUE
───────────────────────────────────────── */
add_action( 'admin_enqueue_scripts', 'sd_gallery_admin_scripts' );
function sd_gallery_admin_scripts( $hook ) {
    if ( in_array( $hook, [ 'post.php', 'post-new.php' ] ) ) {
        $screen = get_current_screen();
        if ( $screen && $screen->post_type === 'sd_project' ) {
            wp_enqueue_media();
            wp_enqueue_script( 'jquery-ui-sortable' );
        }
    }
    $our_pages = [ 'toplevel_page_sd-gallery-dashboard', 'sd-gallery_page_sd-gallery-css', 'sd-gallery_page_sd-gallery-settings' ];
    if ( in_array( $hook, array_merge( $our_pages, [ 'post.php', 'post-new.php' ] ) ) ) {
        wp_enqueue_style(  'sd-gallery-admin', SD_GALLERY_URL . 'assets/safi-gallery-admin.css', [], SD_GALLERY_VERSION );
        wp_enqueue_script( 'sd-gallery-admin', SD_GALLERY_URL . 'assets/safi-gallery-admin.js',  [ 'jquery', 'jquery-ui-sortable' ], SD_GALLERY_VERSION, true );
    }
}

/* ─────────────────────────────────────────
   4. DASHBOARD PAGE
───────────────────────────────────────── */
function sd_gallery_dashboard_page() {
    $projects   = get_posts( [ 'post_type' => 'sd_project', 'posts_per_page' => -1, 'post_status' => 'publish' ] );
    $total_imgs = 0;
    foreach ( $projects as $p ) {
        $ids = get_post_meta( $p->ID, '_sd_gallery_images', true ) ?: [];
        $total_imgs += count( $ids );
    }
    $categories = get_terms( [ 'taxonomy' => 'sd_gallery_cat', 'hide_empty' => false ] );
    ?>
    <div class="safi-dash-wrap">

        <!-- Header -->
        <div class="safi-dash-header">
            <div class="safi-dash-header-left">
                <div class="safi-dash-logo">
                    <span class="dashicons dashicons-format-gallery"></span>
                </div>
                <div>
                    <h1 class="safi-dash-title">SD Media Gallery</h1>
                    <p class="safi-dash-sub">Professional project gallery · Built by <strong>Shohidul Dev</strong> <span class="safi-footer-tag">#shohiduldev</span></p>
                </div>
            </div>
            <a href="<?php echo esc_url( admin_url( 'post-new.php?post_type=sd_project' ) ); ?>" class="safi-btn safi-btn-primary">
                <span class="dashicons dashicons-plus-alt2"></span> Add New Project
            </a>
        </div>

        <!-- Stats -->
        <div class="safi-stats-row">
            <div class="safi-stat-card">
                <span class="safi-stat-icon dashicons dashicons-portfolio"></span>
                <span class="safi-stat-num"><?php echo count( $projects ); ?></span>
                <span class="safi-stat-label">Projects</span>
            </div>
            <div class="safi-stat-card">
                <span class="safi-stat-icon dashicons dashicons-format-image"></span>
                <span class="safi-stat-num"><?php echo $total_imgs; ?></span>
                <span class="safi-stat-label">Total Images</span>
            </div>
            <div class="safi-stat-card">
                <span class="safi-stat-icon dashicons dashicons-category"></span>
                <span class="safi-stat-num"><?php echo count( $categories ); ?></span>
                <span class="safi-stat-label">Categories</span>
            </div>
            <div class="safi-stat-card safi-stat-shortcode">
                <span class="safi-stat-icon dashicons dashicons-editor-code"></span>
                <code>[sd_gallery]</code>
                <span class="safi-stat-label">Shortcode</span>
            </div>
        </div>

        <!-- ⚠️ WARNING BOX -->
        <div class="sd-warning-box">
            <div class="sd-warning-icon">⚠️</div>
            <div class="sd-warning-content">
                <strong>Important: Always use <code>heading</code> and <code>subheading</code> in your shortcode!</strong>
                <p>Without these attributes, the gallery section header will be hidden — this can <strong>break the layout on mobile devices</strong> and make the gallery appear without any context for visitors.</p>
                <div class="sd-warning-example">
                    <span class="sd-warn-label">✅ Correct usage:</span>
                    <code>[sd_gallery columns="3" heading="Our Projects" subheading="Browse our latest work"]</code>
                </div>
                <div class="sd-warning-example sd-warn-bad">
                    <span class="sd-warn-label">❌ Avoid this (no heading = broken mobile view):</span>
                    <code>[sd_gallery columns="3"]</code>
                </div>
            </div>
        </div>

        <!-- How to use -->
        <div class="safi-how-box">
            <div class="safi-how-title">
                <span class="dashicons dashicons-info-outline"></span>
                How to use
            </div>
            <div class="safi-how-steps">
                <div class="safi-how-step">
                    <div class="safi-step-num">1</div>
                    <div class="safi-step-body">
                        <strong>Add a project</strong>
                        <span>Click "Add New Project" → enter title → set Featured Image → add gallery images</span>
                    </div>
                </div>
                <div class="safi-how-step">
                    <div class="safi-step-num">2</div>
                    <div class="safi-step-body">
                        <strong>Multiple images per card</strong>
                        <span>Each project supports unlimited images. Drag to reorder. First = lightbox start</span>
                    </div>
                </div>
                <div class="safi-how-step">
                    <div class="safi-step-num">3</div>
                    <div class="safi-step-body">
                        <strong>Use the shortcode</strong>
                        <span>Always include <code>heading=""</code> and <code>subheading=""</code> for proper mobile display</span>
                    </div>
                </div>
                <div class="safi-how-step">
                    <div class="safi-step-num">4</div>
                    <div class="safi-step-body">
                        <strong>Custom CSS</strong>
                        <span>Go to <a href="<?php echo esc_url( admin_url('admin.php?page=sd-gallery-css') ); ?>">Custom CSS</a> tab to restyle without editing files</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- Shortcode reference -->
        <div class="safi-shortcode-ref">
            <h3 class="safi-section-title">Shortcode Reference</h3>
            <div class="safi-sc-table">
                <div class="safi-sc-row safi-sc-head">
                    <span>Attribute</span><span>Default</span><span>Example</span><span>Description</span>
                </div>
                <div class="safi-sc-row">
                    <span><code>heading</code> <span class="sd-req-badge">required</span></span>
                    <span>—</span>
                    <span><code>heading="Our Projects"</code></span>
                    <span>Section heading — <strong>required for mobile</strong></span>
                </div>
                <div class="safi-sc-row">
                    <span><code>subheading</code> <span class="sd-req-badge">required</span></span>
                    <span>—</span>
                    <span><code>subheading="Quality work"</code></span>
                    <span>Section subheading — <strong>required for mobile</strong></span>
                </div>
                <div class="safi-sc-row"><span><code>columns</code></span><span>3</span><span><code>columns="2"</code></span><span>Grid columns (1–4)</span></div>
                <div class="safi-sc-row"><span><code>category</code></span><span>all</span><span><code>category="bathroom"</code></span><span>Filter by category slug</span></div>
            </div>
            <div class="safi-sc-example">
                <strong>✅ Recommended full shortcode:</strong>
                <code>[sd_gallery columns="3" heading="Our Projects" subheading="Browse our latest work"]</code>
            </div>
        </div>

        <!-- Screenshots / Preview Section -->
        <div class="sd-screenshots-section">
            <h3 class="safi-section-title">Plugin Screenshots</h3>
            <div class="sd-screenshots-grid">
                <div class="sd-screenshot-card">
                    <div class="sd-screenshot-img sd-ss-gallery">
                        <div class="sd-ss-mockup-grid">
                            <div class="sd-ss-card" style="background:linear-gradient(135deg,#0e7a6e,#14b8a6)"></div>
                            <div class="sd-ss-card" style="background:linear-gradient(135deg,#db6b7a,#f0899a)"></div>
                            <div class="sd-ss-card" style="background:linear-gradient(135deg,#4a5568,#718096)"></div>
                            <div class="sd-ss-card" style="background:linear-gradient(135deg,#7c3aed,#a78bfa)"></div>
                            <div class="sd-ss-card" style="background:linear-gradient(135deg,#b45309,#fbbf24)"></div>
                            <div class="sd-ss-card" style="background:linear-gradient(135deg,#0369a1,#38bdf8)"></div>
                        </div>
                    </div>
                    <div class="sd-screenshot-label">
                        <span class="dashicons dashicons-grid-view"></span>
                        Frontend Gallery Grid
                    </div>
                </div>
                <div class="sd-screenshot-card">
                    <div class="sd-screenshot-img sd-ss-lightbox">
                        <div class="sd-ss-lb-mock">
                            <div class="sd-ss-lb-img" style="background:linear-gradient(135deg,#0e7a6e,#14b8a6)"></div>
                            <div class="sd-ss-lb-thumbs">
                                <div style="background:#0e7a6e;border:2px solid #fff"></div>
                                <div style="background:#14b8a6;opacity:.5"></div>
                                <div style="background:#0d9488;opacity:.5"></div>
                            </div>
                        </div>
                    </div>
                    <div class="sd-screenshot-label">
                        <span class="dashicons dashicons-images-alt2"></span>
                        Lightbox with Thumbnails
                    </div>
                </div>
                <div class="sd-screenshot-card">
                    <div class="sd-screenshot-img sd-ss-css">
                        <div class="sd-ss-css-mock">
                            <div class="sd-ss-css-line" style="width:60%;color:#c792ea">.safi-gallery-card {</div>
                            <div class="sd-ss-css-line" style="width:80%;padding-left:16px;color:#82aaff">border-radius: 24px;</div>
                            <div class="sd-ss-css-line" style="width:90%;padding-left:16px;color:#82aaff">box-shadow: 0 8px 32px</div>
                            <div class="sd-ss-css-line" style="width:40%;padding-left:16px;color:#82aaff">rgba(0,0,0,.2);</div>
                            <div class="sd-ss-css-line" style="width:20%;color:#c792ea">}</div>
                            <div class="sd-ss-css-line" style="width:70%;margin-top:6px;color:#c792ea">.safi-gallery-heading {</div>
                            <div class="sd-ss-css-line" style="width:85%;padding-left:16px;color:#82aaff">color: #1a73e8;</div>
                            <div class="sd-ss-css-line" style="width:20%;color:#c792ea">}</div>
                        </div>
                    </div>
                    <div class="sd-screenshot-label">
                        <span class="dashicons dashicons-editor-code"></span>
                        Custom CSS Editor
                    </div>
                </div>
                <div class="sd-screenshot-card">
                    <div class="sd-screenshot-img sd-ss-mobile">
                        <div class="sd-ss-phone">
                            <div class="sd-ss-phone-screen">
                                <div class="sd-ss-ph-heading"></div>
                                <div class="sd-ss-ph-sub"></div>
                                <div class="sd-ss-ph-card" style="background:linear-gradient(135deg,#0e7a6e,#14b8a6)"></div>
                                <div class="sd-ss-ph-card" style="background:linear-gradient(135deg,#db6b7a,#f0899a)"></div>
                            </div>
                        </div>
                    </div>
                    <div class="sd-screenshot-label">
                        <span class="dashicons dashicons-smartphone"></span>
                        Mobile Responsive View
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent projects -->
        <?php if ( ! empty( $projects ) ) : $recent = array_slice( $projects, 0, 6 ); ?>
        <div class="safi-recent-section">
            <div class="safi-recent-header">
                <h3 class="safi-section-title">Recent Projects</h3>
                <a href="<?php echo esc_url( admin_url('edit.php?post_type=sd_project') ); ?>" class="safi-view-all">View all →</a>
            </div>
            <div class="safi-recent-grid">
                <?php foreach ( $recent as $proj ) :
                    $thumb = get_the_post_thumbnail_url( $proj->ID, 'medium' );
                    $ids   = get_post_meta( $proj->ID, '_sd_gallery_images', true ) ?: [];
                    $cnt   = count( $ids );
                ?>
                <a href="<?php echo esc_url( get_edit_post_link( $proj->ID ) ); ?>" class="safi-recent-card">
                    <div class="safi-recent-img" style="<?php echo $thumb ? 'background-image:url('.esc_url($thumb).')' : 'background:#e5e7ea'; ?>">
                        <?php if ( ! $thumb ) echo '<span class="dashicons dashicons-format-image"></span>'; ?>
                        <span class="safi-recent-badge"><?php echo $cnt; ?> img<?php echo $cnt !== 1 ? 's' : ''; ?></span>
                    </div>
                    <div class="safi-recent-body">
                        <span class="safi-recent-title"><?php echo esc_html( get_the_title( $proj ) ); ?></span>
                        <span class="safi-recent-edit">Edit →</span>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Footer -->
        <div class="safi-dash-footer">
            <div class="safi-footer-brand">
                <span>Built by</span>
                <a href="https://github.com/ShohidulDev" target="_blank" rel="noopener">
                    <img src="<?php echo esc_url( SD_GALLERY_URL . 'assets/sd-logo.png' ); ?>" alt="ShohidulDev" class="safi-footer-logo" onerror="this.style.display='none'">
                    <strong>Shohidul Dev</strong>
                </a>
                <span class="safi-footer-tag">#shohiduldev</span>
            </div>
            <div class="safi-footer-links">
                <a href="https://github.com/ShohidulDev" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
                    GitHub
                </a>
                <a href="https://www.linkedin.com/in/shohiduldev" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
                    LinkedIn
                </a>
                <a href="https://www.instagram.com/shohiduldev" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>
                    Instagram
                </a>
                <a href="https://x.com/shohiduldev" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M18.901 1.153h3.68l-8.04 9.19L24 22.846h-7.406l-5.8-7.584-6.638 7.584H.474l8.6-9.83L0 1.154h7.594l5.243 6.932ZM17.61 20.644h2.039L6.486 3.24H4.298Z"/></svg>
                    X / Twitter
                </a>
                <a href="https://www.facebook.com/shohiduldev" target="_blank" rel="noopener">
                    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                    Facebook
                </a>
            </div>
        </div>

    </div>
    <?php
}

/* ─────────────────────────────────────────
   5. CUSTOM CSS PAGE
───────────────────────────────────────── */
function sd_gallery_css_page() {
    if ( isset( $_POST['sd_save_css'] ) && check_admin_referer( 'sd_css_save' ) ) {
        update_option( 'sd_gallery_custom_css', wp_strip_all_tags( $_POST['sd_custom_css'] ) );
        echo '<div class="notice notice-success is-dismissible"><p>✓ Custom CSS saved!</p></div>';
    }
    $css = get_option( 'sd_gallery_custom_css', '' );
    $presets = [
        'default'   => [ 'label' => 'Default',      'css' => '' ],
        'dark'      => [ 'label' => 'Dark Cards',    'css' => ".safi-gallery-card { border-radius: 4px; }\n.safi-card-overlay { background: linear-gradient(to bottom, transparent 30%, rgba(0,0,0,0.9) 100%); }" ],
        'rounded'   => [ 'label' => 'Pill Rounded',  'css' => ".safi-gallery-card { border-radius: 24px; }\n.safi-gallery-heading { color: #2563eb; }" ],
        'minimal'   => [ 'label' => 'Minimal',       'css' => ".safi-gallery-card { box-shadow: none; border: 1px solid #e5e7ea; }\n.safi-gallery-card:hover { transform: none; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }" ],
        'gap-large' => [ 'label' => 'Large Gap',     'css' => ".safi-gallery-grid { gap: 32px; }\n.safi-gallery-section { padding: 60px 20px; }" ],
    ];
    ?>
    <div class="safi-dash-wrap">
        <div class="safi-dash-header">
            <div class="safi-dash-header-left">
                <div class="safi-dash-logo"><span class="dashicons dashicons-editor-code"></span></div>
                <div>
                    <h1 class="safi-dash-title">Custom CSS</h1>
                    <p class="safi-dash-sub">Override gallery styles without editing plugin files</p>
                </div>
            </div>
        </div>
        <div class="safi-css-layout">
            <div class="safi-css-editor-panel">
                <form method="post">
                    <?php wp_nonce_field( 'sd_css_save' ); ?>
                    <div class="safi-css-presets">
                        <label class="safi-field-label">Quick Presets</label>
                        <div class="safi-preset-btns">
                            <?php foreach ( $presets as $key => $preset ) : ?>
                            <button type="button" class="safi-preset-btn" data-css="<?php echo esc_attr( $preset['css'] ); ?>"><?php echo esc_html( $preset['label'] ); ?></button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="safi-css-field">
                        <label class="safi-field-label" for="sd_custom_css">Your CSS <span class="safi-field-hint">Applied to gallery on frontend only</span></label>
                        <textarea id="sd_custom_css" name="sd_custom_css" class="safi-css-textarea" rows="20" spellcheck="false" placeholder="/* Example */&#10;.safi-gallery-card { border-radius: 4px; }&#10;.safi-gallery-heading { color: #1a73e8; }"><?php echo esc_textarea( $css ); ?></textarea>
                    </div>
                    <div class="safi-css-actions">
                        <button type="submit" name="sd_save_css" class="safi-btn safi-btn-primary"><span class="dashicons dashicons-saved"></span> Save CSS</button>
                        <button type="button" id="safi-clear-css" class="safi-btn safi-btn-ghost">Clear</button>
                    </div>
                </form>
            </div>
            <div class="safi-css-ref-panel">
                <div class="safi-ref-box">
                    <h3 class="safi-ref-title">CSS Class Reference</h3>
                    <div class="safi-ref-list">
                        <div class="safi-ref-item"><code>.safi-gallery-section</code><span>Outer wrapper</span></div>
                        <div class="safi-ref-item"><code>.safi-gallery-grid</code><span>Card grid</span></div>
                        <div class="safi-ref-item"><code>.safi-gallery-card</code><span>Each card</span></div>
                        <div class="safi-ref-item"><code>.safi-card-overlay</code><span>Gradient overlay</span></div>
                        <div class="safi-ref-item"><code>.safi-card-title</code><span>Card title text</span></div>
                        <div class="safi-ref-item"><code>.safi-card-count</code><span>Image count</span></div>
                        <div class="safi-ref-item"><code>.safi-gallery-heading</code><span>Section heading</span></div>
                        <div class="safi-ref-item"><code>.safi-gallery-subheading</code><span>Section subheading</span></div>
                        <div class="safi-ref-item"><code>.safi-lightbox</code><span>Lightbox container</span></div>
                        <div class="safi-ref-item"><code>.safi-lb-img</code><span>Main lightbox image</span></div>
                        <div class="safi-ref-item"><code>.safi-lb-thumb</code><span>Thumbnail items</span></div>
                    </div>
                </div>
                <div class="safi-ref-box safi-ref-tip">
                    <h3 class="safi-ref-title">💡 Tips</h3>
                    <ul>
                        <li>Use <code>!important</code> only if needed</li>
                        <li>Test on mobile after any changes</li>
                        <li>Use browser DevTools to find class names</li>
                        <li>Always include <code>heading=""</code> in shortcode</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <script>
    document.querySelectorAll('.safi-preset-btn').forEach(function(btn){
        btn.addEventListener('click',function(){ document.getElementById('sd_custom_css').value=this.dataset.css||''; document.querySelectorAll('.safi-preset-btn').forEach(function(b){b.classList.remove('active');}); this.classList.add('active'); });
    });
    document.getElementById('safi-clear-css').addEventListener('click',function(){ if(confirm('Clear all CSS?')) document.getElementById('sd_custom_css').value=''; });
    </script>
    <?php
}

/* ─────────────────────────────────────────
   6. SETTINGS PAGE
───────────────────────────────────────── */
function sd_gallery_settings_page() {
    if ( isset( $_POST['sd_save_settings'] ) && check_admin_referer( 'sd_settings_save' ) ) {
        update_option( 'sd_gallery_cols',    (int) $_POST['sd_cols'] );
        update_option( 'sd_gallery_animate', isset( $_POST['sd_animate'] ) ? 1 : 0 );
        echo '<div class="notice notice-success is-dismissible"><p>✓ Settings saved!</p></div>';
    }
    $cols    = get_option( 'sd_gallery_cols', 3 );
    $animate = get_option( 'sd_gallery_animate', 1 );
    ?>
    <div class="safi-dash-wrap">
        <div class="safi-dash-header">
            <div class="safi-dash-header-left">
                <div class="safi-dash-logo"><span class="dashicons dashicons-admin-settings"></span></div>
                <div><h1 class="safi-dash-title">Settings</h1><p class="safi-dash-sub">Default gallery behaviour</p></div>
            </div>
        </div>
        <div class="safi-settings-wrap">
            <form method="post">
                <?php wp_nonce_field( 'sd_settings_save' ); ?>
                <div class="safi-settings-card">
                    <h3 class="safi-settings-section">Gallery Defaults</h3>
                    <div class="safi-setting-row">
                        <label class="safi-setting-label">Default Columns</label>
                        <select name="sd_cols" class="safi-select">
                            <?php for ( $i = 1; $i <= 4; $i++ ) : ?>
                            <option value="<?php echo $i; ?>" <?php selected( $cols, $i ); ?>><?php echo $i; ?> Column<?php echo $i > 1 ? 's' : ''; ?></option>
                            <?php endfor; ?>
                        </select>
                        <span class="safi-setting-hint">Overridden by <code>columns=""</code> in shortcode</span>
                    </div>
                    <div class="safi-setting-row">
                        <label class="safi-setting-label">Card Hover Animation</label>
                        <label class="safi-toggle"><input type="checkbox" name="sd_animate" value="1" <?php checked( $animate, 1 ); ?>><span class="safi-toggle-track"></span></label>
                        <span class="safi-setting-hint">Lift effect on hover</span>
                    </div>
                </div>
                <button type="submit" name="sd_save_settings" class="safi-btn safi-btn-primary"><span class="dashicons dashicons-saved"></span> Save Settings</button>
            </form>
        </div>
    </div>
    <?php
}

/* ─────────────────────────────────────────
   7. META BOX
───────────────────────────────────────── */
add_action( 'add_meta_boxes', 'sd_gallery_meta_boxes' );
function sd_gallery_meta_boxes() {
    add_meta_box( 'sd_project_gallery', 'Project Images', 'sd_gallery_meta_box_cb', 'sd_project', 'normal', 'high' );
}
function sd_gallery_meta_box_cb( $post ) {
    wp_nonce_field( 'sd_gallery_save', 'sd_gallery_nonce' );
    $image_ids = get_post_meta( $post->ID, '_sd_gallery_images', true );
    $image_ids = is_array( $image_ids ) ? array_filter( $image_ids ) : [];
    ?>
    <div class="safi-admin-wrap">
        <p class="safi-admin-help">Add as many images as you like. <strong>Drag thumbnails</strong> to reorder. The <strong>Featured Image</strong> is used as the card cover on the front-end.</p>
        <ul id="safi-img-list">
            <?php foreach ( $image_ids as $id ) :
                $src = wp_get_attachment_image_url( $id, 'medium' );
                if ( ! $src ) continue; ?>
                <li class="safi-img-item" data-id="<?php echo esc_attr( $id ); ?>">
                    <img src="<?php echo esc_url( $src ); ?>" alt="">
                    <button type="button" class="safi-img-remove" title="Remove">×</button>
                    <span class="safi-img-drag" title="Drag to reorder">⠿</span>
                </li>
            <?php endforeach; ?>
            <li class="safi-img-add-tile" id="safi-add-tile">
                <button type="button" id="safi-add-images"><span class="safi-add-icon">+</span><span>Add Images</span></button>
            </li>
        </ul>
        <input type="hidden" id="sd_gallery_image_ids" name="sd_gallery_image_ids" value="<?php echo esc_attr( implode( ',', $image_ids ) ); ?>">
        <div class="safi-admin-actions">
            <button type="button" id="safi-add-images-btn" class="button button-primary">＋ Add More Images</button>
            <button type="button" id="safi-clear-all" class="button button-link-delete" <?php echo empty( $image_ids ) ? 'style="display:none"' : ''; ?>>Remove All</button>
            <span class="safi-img-count"><?php $c = count($image_ids); echo $c . ' image' . ($c !== 1 ? 's' : ''); ?></span>
        </div>
    </div>
    <script>
    (function($){
        function currentIds(){ return $('#safi-img-list .safi-img-item').map(function(){ return $(this).data('id'); }).get(); }
        function syncInput(){ var ids=currentIds(); $('#sd_gallery_image_ids').val(ids.join(',')); var c=ids.length; $('.safi-img-count').text(c+' image'+(c!==1?'s':'')); $('#safi-clear-all').toggle(c>0); }
        function addItem(id,src){ if($('#safi-img-list .safi-img-item[data-id="'+id+'"]').length) return; var $li=$('<li class="safi-img-item" data-id="'+id+'"><img src="'+src+'" alt=""><button type="button" class="safi-img-remove" title="Remove">×</button><span class="safi-img-drag" title="Drag to reorder">⠿</span></li>'); $('#safi-add-tile').before($li); syncInput(); }
        function openFrame(){ var frame=wp.media({title:'Select Project Images',button:{text:'Add to gallery'},multiple:'add'}); frame.on('open',function(){ var sel=frame.state().get('selection'); currentIds().forEach(function(id){ var att=wp.media.attachment(id); att.fetch(); sel.add(att?att:[]); }); }); frame.on('select',function(){ frame.state().get('selection').each(function(att){ var sizes=att.attributes.sizes; var src=sizes&&sizes.medium?sizes.medium.url:sizes&&sizes.thumbnail?sizes.thumbnail.url:att.attributes.url; addItem(att.id,src); }); syncInput(); }); frame.open(); }
        $('#safi-add-images, #safi-add-images-btn').on('click',function(e){ e.preventDefault(); openFrame(); });
        $(document).on('click','.safi-img-remove',function(){ $(this).closest('.safi-img-item').remove(); syncInput(); });
        $('#safi-clear-all').on('click',function(){ if(!confirm('Remove all images?')) return; $('#safi-img-list .safi-img-item').remove(); syncInput(); });
        $('#safi-img-list').sortable({items:'.safi-img-item',handle:'.safi-img-drag',placeholder:'safi-img-placeholder',forcePlaceholderSize:true,tolerance:'pointer',update:syncInput});
    })(jQuery);
    </script>
    <?php
}
add_action( 'save_post_sd_project', 'sd_gallery_save_meta' );
function sd_gallery_save_meta( $post_id ) {
    if ( ! isset( $_POST['sd_gallery_nonce'] ) ) return;
    if ( ! wp_verify_nonce( $_POST['sd_gallery_nonce'], 'sd_gallery_save' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    $raw = isset( $_POST['sd_gallery_image_ids'] ) ? sanitize_text_field( $_POST['sd_gallery_image_ids'] ) : '';
    $ids = array_filter( array_map( 'absint', explode( ',', $raw ) ) );
    update_post_meta( $post_id, '_sd_gallery_images', array_values( $ids ) );
}

/* ─────────────────────────────────────────
   8. FRONTEND
───────────────────────────────────────── */
add_action( 'wp_enqueue_scripts', 'sd_gallery_enqueue' );
// Also load inside Elementor editor preview iframe
add_action( 'elementor/preview/enqueue_styles',  'sd_gallery_enqueue' );
add_action( 'elementor/preview/enqueue_scripts', 'sd_gallery_enqueue' );
// Elementor editor panel (for widget rendering)
add_action( 'elementor/editor/after_enqueue_styles',   'sd_gallery_enqueue_css_only' );

function sd_gallery_enqueue() {
    wp_enqueue_style(  'sd-gallery', SD_GALLERY_URL . 'assets/safi-gallery.css', [], SD_GALLERY_VERSION );
    wp_enqueue_script( 'sd-gallery', SD_GALLERY_URL . 'assets/safi-gallery.js',  [ 'jquery' ], SD_GALLERY_VERSION, true );
    $custom_css = get_option( 'sd_gallery_custom_css', '' );
    if ( $custom_css ) wp_add_inline_style( 'sd-gallery', $custom_css );
}

function sd_gallery_enqueue_css_only() {
    wp_enqueue_style( 'sd-gallery', SD_GALLERY_URL . 'assets/safi-gallery.css', [], SD_GALLERY_VERSION );
    $custom_css = get_option( 'sd_gallery_custom_css', '' );
    if ( $custom_css ) wp_add_inline_style( 'sd-gallery', $custom_css );
}

/* ─────────────────────────────────────────
   9. SHORTCODE [sd_gallery]
───────────────────────────────────────── */
add_shortcode( 'sd_gallery', 'sd_gallery_shortcode' );
function sd_gallery_shortcode( $atts ) {
    $default_cols = get_option( 'sd_gallery_cols', 3 );
    $atts = shortcode_atts( [ 'category' => '', 'columns' => $default_cols, 'heading' => '', 'subheading' => '' ], $atts, 'sd_gallery' );
    $columns = max( 1, min( 4, (int) $atts['columns'] ) );

    /* ── Warning if heading/subheading missing ── */
    $warning = '';
    if ( current_user_can('manage_options') && ( empty($atts['heading']) || empty($atts['subheading']) ) ) {
        $missing = [];
        if ( empty($atts['heading']) )    $missing[] = '<code>heading=""</code>';
        if ( empty($atts['subheading']) ) $missing[] = '<code>subheading=""</code>';
        $warning = '<div class="sd-gallery-warning">
            <strong>⚠️ SD Gallery Warning (visible to admins only):</strong>
            Missing ' . implode(' and ', $missing) . ' in your shortcode.
            Without these, the gallery header will be hidden and <strong>mobile view may break</strong>.<br>
            <strong>Recommended:</strong> <code>[sd_gallery columns="3" heading="Our Projects" subheading="Browse our latest work"]</code>
        </div>
        <style>
        .sd-gallery-warning{background:#fff8e1;border:2px solid #f59e0b;border-radius:8px;padding:14px 18px;margin-bottom:20px;font-size:13px;line-height:1.6;color:#78350f;}
        .sd-gallery-warning code{background:#fef3c7;padding:2px 6px;border-radius:4px;font-size:12px;}
        </style>';
    }

    $query_args = [ 'post_type' => 'sd_project', 'posts_per_page' => -1, 'post_status' => 'publish', 'orderby' => 'menu_order', 'order' => 'ASC' ];
    if ( $atts['category'] ) {
        $query_args['tax_query'] = [ [ 'taxonomy' => 'sd_gallery_cat', 'field' => 'slug', 'terms' => sanitize_text_field( $atts['category'] ) ] ];
    }
    $projects = get_posts( $query_args );
    if ( empty( $projects ) ) return $warning . '<p class="safi-empty">No projects found.</p>';

    $all_lightbox = [];
    foreach ( $projects as $project ) {
        $image_ids = get_post_meta( $project->ID, '_sd_gallery_images', true ) ?: [];
        $images = [];
        foreach ( $image_ids as $img_id ) {
            $full  = wp_get_attachment_image_url( $img_id, 'large' );
            $thumb = wp_get_attachment_image_url( $img_id, 'thumbnail' );
            if ( $full ) $images[] = [ 'full' => $full, 'thumb' => $thumb ];
        }
        if ( empty( $images ) && has_post_thumbnail( $project->ID ) ) {
            $images[] = [ 'full' => get_the_post_thumbnail_url( $project->ID, 'large' ), 'thumb' => get_the_post_thumbnail_url( $project->ID, 'thumbnail' ) ];
        }
        $all_lightbox[ $project->ID ] = $images;
    }

    ob_start();
    echo $warning;
    ?>
    <section class="safi-gallery-section">
        <?php if ( $atts['heading'] || $atts['subheading'] ) : ?>
        <div class="safi-gallery-header">
            <?php if ( $atts['heading'] )    echo '<h2 class="safi-gallery-heading">'   . esc_html( $atts['heading'] )    . '</h2>'; ?>
            <?php if ( $atts['subheading'] ) echo '<p class="safi-gallery-subheading">' . esc_html( $atts['subheading'] ) . '</p>'; ?>
        </div>
        <?php endif; ?>
        <div class="safi-gallery-grid safi-cols-<?php echo esc_attr( $columns ); ?>">
            <?php foreach ( $projects as $project ) :
                $images    = $all_lightbox[ $project->ID ];
                $count     = count( $images );
                $thumb_url = has_post_thumbnail( $project->ID ) ? get_the_post_thumbnail_url( $project->ID, 'large' ) : ( ! empty( $images ) ? $images[0]['full'] : '' );
                if ( ! $thumb_url ) continue;
            ?>
            <div class="safi-gallery-card"
                 data-project-id="<?php echo esc_attr( $project->ID ); ?>"
                 data-images='<?php echo esc_attr( wp_json_encode( $images ) ); ?>'
                 data-title="<?php echo esc_attr( get_the_title( $project ) ); ?>"
                 style="background-image:url('<?php echo esc_url( $thumb_url ); ?>')">
                <div class="safi-card-overlay">
                    <div class="safi-card-info">
                        <span class="safi-card-title"><?php echo esc_html( get_the_title( $project ) ); ?></span>
                        <span class="safi-card-count"><?php echo $count . ' image' . ( $count !== 1 ? 's' : '' ); ?></span>
                    </div>
                    <span class="safi-card-arrow">›</span>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </section>
    <div id="safi-lightbox" class="safi-lightbox" role="dialog" aria-modal="true" aria-label="Image viewer" hidden>
        <button class="safi-lb-close" aria-label="Close">×</button>
        <button class="safi-lb-prev" aria-label="Previous">‹</button>
        <button class="safi-lb-next" aria-label="Next">›</button>
        <div class="safi-lb-inner">
            <img class="safi-lb-img" src="" alt="">
            <div class="safi-lb-caption"><span class="safi-lb-title"></span><span class="safi-lb-counter"></span></div>
            <div class="safi-lb-thumbs"></div>
        </div>
    </div>
    <div id="safi-lb-backdrop" class="safi-lb-backdrop" hidden></div>
    <?php
    return ob_get_clean();
}

/* ─────────────────────────────────────────
   10. ACTIVATION
───────────────────────────────────────── */
register_activation_hook( __FILE__, function(){
    sd_gallery_register_cpt();
    flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );
